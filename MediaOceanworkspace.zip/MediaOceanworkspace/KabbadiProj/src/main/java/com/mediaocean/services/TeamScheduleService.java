package com.mediaocean.services;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.mediaocean.model.TeamMatchSchedule;

@Repository
@Transactional
public class TeamScheduleService {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public void scheduleMatch(TeamMatchSchedule teamMatchSchedule) {
		entityManager.persist(teamMatchSchedule);
	}
	
	public void clearSchedules(){
		entityManager.createQuery("delete from TeamMatchSchedule e").executeUpdate();
	}

	public boolean isMatchPlannedOnADateForaTeam(Date date, String team) {
		List<String> teamNames = entityManager
				.createQuery("select e.teamId from TeamMatchSchedule e where (e.team1 = :team or e.team2 = :team) and "
						+ "(DATE(e.plannedDate) = DATE(:date) or DATE(e.plannedDate -1) = DATE(:date) or DATE(e.plannedDate + 1) = DATE(:date))")
				.setParameter("team", team).setParameter("date", date).getResultList();
		if (!CollectionUtils.isEmpty(teamNames))
			return true;
		return false;
	}

	public boolean havePlayedEachOther(String team1, String team2) {
		List<String> teamNames = entityManager
				.createQuery("select e.teamId from TeamMatchSchedule e where e.team1 =  :team1 and e.team2 =  :team2")
				.setParameter("team1", team1).setParameter("team2", team2).getResultList();
		if (!CollectionUtils.isEmpty((teamNames)))
			return true;
		return false;
	}
	
	public int getGamesScheduledOnADay(Date date) {
		List<String> teamIds = entityManager
				.createQuery("select e.teamId from TeamMatchSchedule e where DATE(e.plannedDate) = DATE(:date)")
				.setParameter("date", date).getResultList();
		
		return teamIds.size();
	}
	

	public int getMatchesScheduled() {
		List<Long> matchesScheduled = entityManager.createQuery("select e.teamId from TeamMatchSchedule e")
				.getResultList();
		if (!CollectionUtils.isEmpty(matchesScheduled))
			return matchesScheduled.size();

		return 0;
	}
}
