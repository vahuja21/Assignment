package com.mediaocean.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mediaocean.model.TeamMatchSchedule;
import com.mediaocean.services.TeamScheduleService;

@RestController
public class TeamScheduleController {

	@Autowired
	TeamScheduleService teamScheduleService;

	@RequestMapping(value = "/teamschedule/{numberofteams}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> generateSchedule(@PathVariable("numberofteams") int num) {
		String output = generateScheduleOutput(num);
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}

	private String generateScheduleOutput(int numberOfTeams) {
		// Home & Away Number of Games
		int numberOfGames = numberOfTeams * (numberOfTeams - 1);
		int matchesScheduled = 0;

		StringBuffer schedule = new StringBuffer();
		schedule.append("Team1\tTeam2\tPlanned Date\tLocation\n");

		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");

		// Clear Previous Schedules
		teamScheduleService.clearSchedules();
		while (matchesScheduled != numberOfGames) {
			matchesScheduled = teamScheduleService.getMatchesScheduled();
			for (int i = 1; i <= numberOfTeams; i++) {
				for (int j = numberOfTeams; j > 0; j--) {
					if (i != j) {
						if (!havePlayedEachOther("Team" + i, "Team" + j) && (getGamesScheduledOnADay(date) < 2)) {
							if (!isMatchPlannedOnADateForaTeam(date, "Team" + i)
									&& !isMatchPlannedOnADateForaTeam(date, "Team" + j)) {
								// Schedule Match;
								System.out.println("Team" + i + " VS " + "Team" + j);
								scheduleMatch("Team" + i, "Team" + j, date);
								schedule.append("Team" + i + "\tTeam" + j + "\t" + simpleDateFormat.format(date) + "\t"
										+ "Team" + i + "_Home\n");
							}
						}
					}
				}
			}
			//Increament a day
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.add(Calendar.DATE, 1);
			date = cal.getTime();
		}

		return schedule.toString();
	}

	private boolean isMatchPlannedOnADateForaTeam(Date date, String team) {
		return teamScheduleService.isMatchPlannedOnADateForaTeam(date, team);
	}

	private boolean havePlayedEachOther(String team1, String team2) {
		return teamScheduleService.havePlayedEachOther(team1, team2);
	}

	private int getGamesScheduledOnADay(Date date) {
		return teamScheduleService.getGamesScheduledOnADay(date);
	}

	private void scheduleMatch(String team1, String team2, Date plannedDate) {
		TeamMatchSchedule teamMatchSchedule = new TeamMatchSchedule();
		teamMatchSchedule.setTeam1(team1);
		teamMatchSchedule.setTeam2(team2);
		teamMatchSchedule.setPlannedDate(plannedDate);
		teamMatchSchedule.setLocation(team1 + "_Home");
		teamScheduleService.scheduleMatch(teamMatchSchedule);
	}

}